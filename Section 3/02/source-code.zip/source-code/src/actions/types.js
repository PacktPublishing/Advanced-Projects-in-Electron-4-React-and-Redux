export const START_FETCHING_CATEGORIES = "start_fetching_categories";
