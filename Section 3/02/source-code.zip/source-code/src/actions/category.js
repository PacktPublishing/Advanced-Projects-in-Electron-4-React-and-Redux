import { START_FETCHING_CATEGORIES } from "../actions/types";

export const startFetchingCategories = () => {
  return { type: START_FETCHING_CATEGORIES };
};
