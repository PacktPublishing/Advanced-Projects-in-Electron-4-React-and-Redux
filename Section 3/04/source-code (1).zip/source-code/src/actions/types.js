export const GET_CATEGORIES = "get_categories";
export const START_FETCHING_CATEGORIES = "start_fetching_categories";
