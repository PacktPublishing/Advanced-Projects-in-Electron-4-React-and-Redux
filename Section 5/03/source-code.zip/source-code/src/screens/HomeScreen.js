import React, { Component } from "react";

class HomeScreen extends Component {
  render() {
    return (
      <div>
        <h1>HomeScreen</h1>
      </div>
    );
  }
}

export default HomeScreen;
