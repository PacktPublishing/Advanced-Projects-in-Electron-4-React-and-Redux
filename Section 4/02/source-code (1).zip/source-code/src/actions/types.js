//categories types
export const GET_CATEGORIES = "get_categories";
export const START_FETCHING_CATEGORIES = "start_fetching_categories";
export const SELECT_CATEGORY = "select_category";
//movies types
export const START_FETCHING_MOVIES = "start_fetching_movies";
export const GET_MOVIES = "get_movies";
export const SELECT_MOVIE = "select_movie";
export const CLOSE_MOVIE = "close_movie";
