export const GET_VIDEO_INFO = "get_video_info";
export const VIDEO_PROGRESS = "video_progress";
export const VIDEO_DOWNLOADED = "video_downloaded";
export const START_DOWNLOADING = "start_downloading";
export const VIDEO_DONE = "video_done";
export const VIDEO_ERROR = "video_error";

// Settings Types
export const SET_SETTINGS = "set_settings";
export const FOLDER_CHANGE = "folder_change";
